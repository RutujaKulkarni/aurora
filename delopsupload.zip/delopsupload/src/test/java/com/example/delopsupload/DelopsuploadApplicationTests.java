package com.example.delopsupload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DelopsuploadApplicationTests {

	@Test
	void contextLoads() {
	}

}

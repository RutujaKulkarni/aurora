package com.example.delopsupload.models;

import java.io.Serializable;

public class ProjectLeadId implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3223943897481082851L;
	private int Chorus_Code;
	private int Year;
	private String Month;

	public ProjectLeadId() {
	}

	public ProjectLeadId(int chorus_Code, int year, String month) {
		super();
		Chorus_Code = chorus_Code;
		Year = year;
		Month = month;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Chorus_Code;
		result = prime * result + ((Month == null) ? 0 : Month.hashCode());
		result = prime * result + Year;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProjectLeadId other = (ProjectLeadId) obj;
		if (Chorus_Code != other.Chorus_Code)
			return false;
		if (Month == null) {
			if (other.Month != null)
				return false;
		} else if (!Month.equals(other.Month))
			return false;
		if (Year != other.Year)
			return false;
		return true;
	}

}

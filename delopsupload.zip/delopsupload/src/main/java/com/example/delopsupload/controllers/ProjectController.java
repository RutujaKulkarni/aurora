package com.example.delopsupload.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.DataFormatException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.delopsupload.models.Response;
import com.example.delopsupload.services.ProjectLeadService;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ProjectController {
	
	@Autowired
	private ProjectLeadService service;
	@PostMapping("/uploadFile")
	public ResponseEntity<Response> uploadFile(@RequestParam("file") MultipartFile file) throws IllegalStateException, IOException, DataFormatException  {
		
		InputStream in = file.getInputStream();
	    File currDir = new File(".");
	    String path = currDir.getAbsolutePath();
	    String fileLocation = path.substring(0, path.length() - 1) + file.getOriginalFilename();
	    FileOutputStream f = new FileOutputStream(fileLocation);
	    int ch = 0;
	    while ((ch = in.read()) != -1) {
	        f.write(ch);
	    }
	    f.flush();
	    f.close();
	    System.out.println("In the controller");
		String s = service.phraseFile(fileLocation);
		
		if(s.equals("Saved Successfully")) {
			Response response = new Response("Excel file has been uploaded sucessfully");
			return new ResponseEntity<Response>(response,HttpStatus.OK);
		}
		else {
			throw new DataFormatException(s);
		}
		
	
	}
}

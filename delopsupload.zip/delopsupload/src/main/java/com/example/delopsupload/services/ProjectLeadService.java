package com.example.delopsupload.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.example.delopsupload.models.ProjectLeadingIndicatorModel;
import com.example.delopsupload.repository.ProjectLeadingIndicatorRepository;

@Service

public class ProjectLeadService {
	
	@Autowired
	private ProjectLeadingIndicatorRepository repository;
	
	ProjectLeadingIndicatorModel indicatorModel = new ProjectLeadingIndicatorModel();

	
public String phraseFile(String file) throws IllegalStateException, IOException {
		
		System.out.println("service layer");

		try {
			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(0);

			// Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			rowIterator.next();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();

				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					/*
					 * Method m = getMethod(cell.getColumnIndex()); System.out.println(m.getName());
					 * System.out.println( "    " +m.getName().equals("setSignedEffectiveDate")); if
					 * (m.getName().equals("setSignedEffectiveDate") ||
					 * m.getName().equals("setStartDate") || m.getName().equals("setStartDate")) {
					 * m.invoke(sow, cell.getDateCellValue()); }else if
					 * (m.getName().equals("tenture")) { m.invoke(sow, cell.getNumericCellValue());
					 * }else { m.invoke(sow, cell.getStringCellValue()); }
					 */
					// System.out.println(m);
					// m.invoke(sow, cell.getStringCellValue());
					switch (cell.getColumnIndex()) {
							case 0:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setChorus_Code((int)cell.getNumericCellValue());
									indicatorModel.setChourusCodeFk((int)cell.getNumericCellValue()); 
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 1:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setYear(((int)cell.getNumericCellValue()));
									break;
								} else {
									return "Error in excel file you prvided. Please have look at the given line of " + "Sheet Name  : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 2:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue() + "	| ");
									indicatorModel.setMonth(cell.getStringCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : " + "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 3:
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue() + "	| ");
									indicatorModel.setProject_Health(cell.getStringCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided Please have look at the given line : " + "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 4:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setRevenue((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided Please have look at the given line : " + "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 5:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided Please have look at the given line : " + "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 6:
								
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setMargin(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided Please have look at the given line : " + "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 7:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost_Tier0(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided Please have look at the given line : " + "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 8:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost_Tier1((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 9:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost_Tier2((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 10:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost_Tier3((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 11:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost_Tier4((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 12:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setFTE_Tier0(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 13:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setFTE_Tier1(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 14:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setFTE_Tier2(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 15:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setFTE_Tier3(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 16:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setFTE_Tier4(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 17:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setContractor_Cost(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 18:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setContractor_Count(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 19:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_R_Cost_Tier0((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 20:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_R_Cost_Tier1((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 21:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_R_Cost_Tier2((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 22:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_R_Cost_Tier3((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 23:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_R_Cost_Tier4((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 24:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_R_Cost_Tier0(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 25:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_R_Cost_Tier1(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 26:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_R_Cost_Tier2(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 27:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_R_Cost_Tier3(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 28:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_R_Cost_Tier4(((int)cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 29:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_FTE_Tier0((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 30:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_FTE_Tier1((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 31:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_FTE_Tier2((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 32:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_FTE_Tier3((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 33:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOnsite_FTE_Tier4((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 34:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_FTE_Tier0((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 35:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_FTE_Tier1((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
		
							case 36:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_FTE_Tier2((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 37:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_FTE_Tier3((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 38:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setOffshore_FTE_Tier4((BigDecimal.valueOf(cell.getNumericCellValue())));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 39:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setDMI_Score(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 40:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setInternal_Fulfillments_Number((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 41:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setExternal_Fulfillments_Number((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 42:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setInterviews_Held_Number((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 43:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setClient_Rejections_Number((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 44:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setCost_Of_Hiring(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 45:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setPast_Due_RRs((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 46:
								
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int)cell.getNumericCellValue() + "	| ");
									indicatorModel.setAgeing_Of_PastDue_RRs((int)cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 47:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setSOW_Value(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 48:
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setEIP_Value(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 49:
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print(cell.getNumericCellValue() + "	| ");
									indicatorModel.setSavings_RFP(BigDecimal.valueOf(cell.getNumericCellValue()));
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : %%%%%%%%%%%%% " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 50: 
		
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.println("retention ");
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setRetention_Issue((int) cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : !!!!!!!!!!!!!!!!!!!! "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 51:
		
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue() + "	| ");
									indicatorModel.setResourceOnboardingDelay(cell.getStringCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line *********************: "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 52:
		
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue() + "	| ");
									indicatorModel.setEIQ_Baselining_Of_Resources(cell.getStringCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : @@@@@@@@@@@@@@@@@@"+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 53:
								
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setChurn_Attrition_Count((int) cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 54:
								
								if (cell.getCellTypeEnum() == CellType.NUMERIC) {
									System.out.print((int) cell.getNumericCellValue() + "	| ");
									indicatorModel.setChurn_Excused_Count((int) cell.getNumericCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
								
							case 55:
								try {

									if (cell.getCellTypeEnum() == CellType.STRING) {
										indicatorModel.setCreated_Date(null);
										break;
									} else {
										System.out.print(cell.getDateCellValue() + "	| ");
										indicatorModel.setCreated_Date(cell.getDateCellValue());
										break;
									}

								} catch (Exception e) {
									System.out.println("Error in date entered");
								}
							case 56:
								
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue() + "	| ");
									indicatorModel.setCreated_By(cell.getStringCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							case 57:
								try {

									if (cell.getCellTypeEnum() == CellType.STRING) {
										indicatorModel.setModified_Date(null);
										break;
									} else {
										System.out.print(cell.getDateCellValue() + "	| ");
										indicatorModel.setModified_Date(cell.getDateCellValue());
										break;
									}

								} catch (Exception e) {
									System.out.println("Error in date entered");
								}
								
							case 58:
								
								if (cell.getCellTypeEnum() == CellType.STRING) {
									System.out.print(cell.getStringCellValue() + "	| ");
									indicatorModel.setModified_By(cell.getStringCellValue());
									break;
								} else {
									String s = "sheet name " + cell.getSheet().getSheetName() + "     Row number "
											+ cell.getRowIndex() + "  column number" + cell.getColumnIndex();
									return "Error in excel file you prvided. Please have look at the given line : "+ "Sheet Name : " + cell.getSheet().getSheetName() + " Row Number : " + cell.getRowIndex() + " Column Index : " + cell.getColumnIndex()
											+ " Try again by after modifications";
								}
							
								
		
							
							
					
					
					}

				
				
				
				
				}
				repository.save(indicatorModel);
				System.out.println("");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Saved Successfully";
	}
}

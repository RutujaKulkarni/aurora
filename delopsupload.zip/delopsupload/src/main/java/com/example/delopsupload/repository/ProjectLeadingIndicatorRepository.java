package com.example.delopsupload.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.delopsupload.models.ProjectLeadId;
import com.example.delopsupload.models.ProjectLeadingIndicatorModel;



public interface ProjectLeadingIndicatorRepository extends JpaRepository<ProjectLeadingIndicatorModel,ProjectLeadId>{

}

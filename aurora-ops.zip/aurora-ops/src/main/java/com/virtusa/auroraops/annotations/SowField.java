package com.virtusa.auroraops.annotations;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Specifies the name of the column (header) from excel sheet being uploaded.
 * 
 * @author kulka
 */
@Target({ FIELD })
@Retention(RUNTIME)
public @interface SowField {
	public String col() default "";
}

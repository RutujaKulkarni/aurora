package com.virtusa.auroraops.models;
import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
/**
 * @author pradip
 * @category Master table
 * CHORUS_MASTER
 */
@Entity
@Table(name="CHORUS_MASTER")
public class ChorusMasterModel {
	
	@Id
	@Column(name = "Chorus_Code",nullable = false)
	private int Chorus_Code;

	@Column(name = "Chorus_Project_Name",columnDefinition="char(15)",nullable = false)
	private String Chorus_Project_Name;
	
	@Column(name = "Chorus_Start_Date",nullable = false)
	private Date Chorus_Start_Date;
	
	@Column(name = "Chorus_End_Date",nullable = false)
	private Date Chorus_End_Date;
	
	@Column(name = "Process_Template",columnDefinition="char(15)",nullable = false)
	private String Process_Template;
	
	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	
	@Column(name = "Created_By",columnDefinition="char(100)",nullable = false)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = false)
	private Date Modified_Date;
	
	@Column(name = "Modified_By",columnDefinition="char(100)",nullable = false)
	private String Modified_By;
	
	
	
	@OneToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL,mappedBy="chorusModel")
	//@JoinColumn(name="cid_fk")
	private  ProjectLeadingIndicatorModel projectLeadingIndicatorModel;
	
	public ChorusMasterModel() {}

	public ChorusMasterModel(int chorus_Code, String chorus_Project_Name, Date chorus_Start_Date, Date chorus_End_Date,
			String process_Template, Date created_Date, String created_By, Date modified_Date, String modified_By) {
		super();
		Chorus_Code = chorus_Code;
		Chorus_Project_Name = chorus_Project_Name;
		Chorus_Start_Date = chorus_Start_Date;
		Chorus_End_Date = chorus_End_Date;
		Process_Template = process_Template;
		Created_Date = created_Date;
		Created_By = created_By;
		Modified_Date = modified_Date;
		Modified_By = modified_By;
	}
	
	

}

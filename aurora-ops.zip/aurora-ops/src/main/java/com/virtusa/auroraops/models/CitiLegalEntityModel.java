package com.virtusa.auroraops.models;
import javax.persistence.Column;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**
 * @author pradip
 * @category look up table
 * CITI_LEGAL_ENTITY
 */
@Entity
@Table(name="CITI_LEGAL_ENTITY")
public class CitiLegalEntityModel {
	@Id
	@Column(name = "Aurora_Citi_Legal_Entity_Seq",nullable = false)
	private int Aurora_Citi_Legal_Entity_Seq;
	
	@Column(name = "Citi_Legal_Entity_Value",columnDefinition="char(30)",nullable = false)
	private String Citi_Legal_Entity_Value;
	
	@OneToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="Aurora_Citi_Legal_Entity_Seq_fk",referencedColumnName="Aurora_Citi_Legal_Entity_Seq")
	List<SowMasterModel> smodel = new ArrayList<>();
	
	public CitiLegalEntityModel() {
		
	}
	

	public CitiLegalEntityModel(int aurora_Citi_Legal_Entity_Seq, String citi_Legal_Entity_Value,
			List<SowMasterModel> smodel) {
		super();
		Aurora_Citi_Legal_Entity_Seq = aurora_Citi_Legal_Entity_Seq;
		Citi_Legal_Entity_Value = citi_Legal_Entity_Value;
		this.smodel = smodel;
	}


	public int getAurora_Citi_Legal_Entity_Seq() {
		return Aurora_Citi_Legal_Entity_Seq;
	}

	public void setAurora_Citi_Legal_Entity_Seq(int aurora_Citi_Legal_Entity_Seq) {
		Aurora_Citi_Legal_Entity_Seq = aurora_Citi_Legal_Entity_Seq;
	}

	public String getCiti_Legal_Entity_Value() {
		return Citi_Legal_Entity_Value;
	}

	public void setCiti_Legal_Entity_Value(String citi_Legal_Entity_Value) {
		Citi_Legal_Entity_Value = citi_Legal_Entity_Value;
	}

	public List<SowMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}
	

		

}

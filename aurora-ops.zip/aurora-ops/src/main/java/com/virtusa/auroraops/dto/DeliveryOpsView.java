package com.virtusa.auroraops.dto;

import java.math.BigDecimal;

public class DeliveryOpsView {

	private String projectCode; // project master model -> velocity code
	private String projectName; // project master model -> 
	private String projectHealth; // project leading model
	private int onsiteFteCount;
	private int offshoreFteCount;
	private int pastDueRrs; // project leading model
	private int ageingOfPastDueRrs; // project leading model
	private String resourceOnboardingDelay; // project leading model
	private String eiqBaseliningOfResources; // project leading model
	private int attritionCount; // project leading model
	private int revenue; // project leading model
	private int cost; // project leading model
	private BigDecimal margin; // project leading model
	private int chorusCode; // identifier for projectLeadingModel
	private int year;
	private String month;
	
	public DeliveryOpsView(String projectCode, String projectName, String projectHealth, int onsiteFteCount,
			int offshoreFteCount, int pastDueRrs, int ageingOfPastDueRrs, String resourceOnboardingDelay,
			String eiqBaseliningOfResources, int attritionCount, int revenue, int cost, BigDecimal margin,
			int chorus_Code, int year, String month, String velocityProjectCode) {
		super();
		this.projectCode = projectCode;
		this.projectName = projectName;
		this.projectHealth = projectHealth;
		this.onsiteFteCount = onsiteFteCount;
		this.offshoreFteCount = offshoreFteCount;
		this.pastDueRrs = pastDueRrs;
		this.ageingOfPastDueRrs = ageingOfPastDueRrs;
		this.resourceOnboardingDelay = resourceOnboardingDelay;
		this.eiqBaseliningOfResources = eiqBaseliningOfResources;
		this.attritionCount = attritionCount;
		this.revenue = revenue;
		this.cost = cost;
		this.margin = margin;
		this.chorusCode = chorus_Code;
		this.year = year;
		this.month = month;
	}

	public DeliveryOpsView() {
	}

	@Override
	public String toString() {
		return "DeliveryOpsView [projectCode=" + projectCode + ", projectName=" + projectName + ", projectHealth="
				+ projectHealth + ", onsiteFteCount=" + onsiteFteCount + ", offshoreFteCount=" + offshoreFteCount
				+ ", pastDueRrs=" + pastDueRrs + ", ageingOfPastDueRrs=" + ageingOfPastDueRrs
				+ ", resourceOnboardingDelay=" + resourceOnboardingDelay + ", eiqBaseliningOfResources="
				+ eiqBaseliningOfResources + ", attritionCount=" + attritionCount + ", revenue=" + revenue + ", cost="
				+ cost + ", margin=" + margin + ", chorusCode=" + chorusCode + ", year=" + year + ", month=" + month
				+ ", " + "]";
	}

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
		System.out.println("----------------------------------setProjectCode");
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
		System.out.println("----------------------------------setProjectName");
	}

	public String getProjectHealth() {
		return projectHealth;
	}

	public void setProjectHealth(String projectHealth) {
		this.projectHealth = projectHealth;
		System.out.println("----------------------------------setProjectHealth");
	}

	public int getOnsiteFteCount() {
		return onsiteFteCount;
	}

	public void setOnsiteFteCount(int onsiteFteCount) {
		this.onsiteFteCount = onsiteFteCount;
		System.out.println("----------------------------------setOnsiteFteCount");
	}

	public int getOffshoreFteCount() {
		return offshoreFteCount;
	}

	public void setOffshoreFteCount(int offshoreFteCount) {
		this.offshoreFteCount = offshoreFteCount;
		System.out.println("----------------------------------setOffshoreFteCount");
	}

	public int getPastDueRrs() {
		return pastDueRrs;
	}

	public void setPastDueRrs(int pastDueRrs) {
		this.pastDueRrs = pastDueRrs;
		System.out.println("----------------------------------setPastDueRrs");
	}

	public int getAgeingOfPastDueRrs() {
		return ageingOfPastDueRrs;
	}

	public void setAgeingOfPastDueRrs(int ageingOfPastDueRrs) {
		this.ageingOfPastDueRrs = ageingOfPastDueRrs;
	}

	public String getResourceOnboardingDelay() {
		return resourceOnboardingDelay;
	}

	public void setResourceOnboardingDelay(String resourceOnboardingDelay) {
		this.resourceOnboardingDelay = resourceOnboardingDelay;
	}

	public String getEiqBaseliningOfResources() {
		return eiqBaseliningOfResources;
	}

	public void setEiqBaseliningOfResources(String eiqBaseliningOfResources) {
		this.eiqBaseliningOfResources = eiqBaseliningOfResources;
	}

	public int getAttritionCount() {
		return attritionCount;
	}

	public void setAttritionCount(int attritionCount) {
		this.attritionCount = attritionCount;
	}

	public int getRevenue() {
		return revenue;
	}

	public void setRevenue(int revenue) {
		this.revenue = revenue;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public BigDecimal getMargin() {
		return margin;
	}

	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}

	public int getChorusCode() {
		return chorusCode;
	}

	public void setChorusCode(int chorusCode) {
		this.chorusCode = chorusCode;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}
	
}

package com.virtusa.auroraops.dto;

import java.math.BigDecimal;

public class DeliveryOpsDTO {
	
	private String projectCode; 	//project master model
	private String projectName; 	//project master model -> velocity code
	private String projectHealth; 	//project leading model
	private int onsiteFteCount;
	private int offshoreFteCount;
	private int pastDueRrs; 		//project leading model
	private int ageingOfPastDueRrs;	//project leading model
	private String resourceOnboardingDelays;	//project leading model
	private String eiqBaseliningOfResources;	//project leading model
	private int attritionCount;		//project leading model
	private int revenue;			//project leading model
	private int cost;				//project leading model
	private BigDecimal margin;			//project leading model
	
	private int Chorus_Code; //identifier for projectLeadingModel
	private int Year;
	private String Month;
	
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		Month = month;
	}
	public int getChorus_Code() {
		return Chorus_Code;
	}
	public void setChorus_Code(int chorus_Code) {
		Chorus_Code = chorus_Code;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectHealth() {
		return projectHealth;
	}
	public void setProjectHealth(String projectHealth) {
		this.projectHealth = projectHealth;
	}
	public int getOnsiteFteCount() {
		return onsiteFteCount;
	}
	public void setOnsiteFteCount(int onsiteFteCount) {
		this.onsiteFteCount = onsiteFteCount;
	}
	public int getOffshoreFteCount() {
		return offshoreFteCount;
	}
	public void setOffshoreFteCount(int offshoreFteCount) {
		this.offshoreFteCount = offshoreFteCount;
	}
	public int getPastDueRrs() {
		return pastDueRrs;
	}
	public void setPastDueRrs(int pastDueRrs) {
		this.pastDueRrs = pastDueRrs;
	}
	public int getAgeingOfPastDueRrs() {
		return ageingOfPastDueRrs;
	}
	public void setAgeingOfPastDueRrs(int ageingOfPastDueRrs) {
		this.ageingOfPastDueRrs = ageingOfPastDueRrs;
	}
	public String getResourceOnboardingDelays() {
		return resourceOnboardingDelays;
	}
	public void setResourceOnboardingDelays(String resourceOnboardingDelays) {
		this.resourceOnboardingDelays = resourceOnboardingDelays;
	}
	public String getEiqBaseliningOfResources() {
		return eiqBaseliningOfResources;
	}
	public void setEiqBaseliningOfResources(String eiqBaseliningOfResources) {
		this.eiqBaseliningOfResources = eiqBaseliningOfResources;
	}
	public int getAttritionCount() {
		return attritionCount;
	}
	public void setAttritionCount(int attritionCount) {
		this.attritionCount = attritionCount;
	}
	public int getRevenue() {
		return revenue;
	}
	public void setRevenue(int revenue) {
		this.revenue = revenue;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public BigDecimal getMargin() {
		return margin;
	}
	public void setMargin(BigDecimal margin) {
		this.margin = margin;
	}
	
}



package com.virtusa.auroraops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuroraopsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuroraopsApplication.class, args);
	}
}

//package com.virtusa.auroraops.models;
package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author pradip
 * @category look up table
 * SERVICE_TYPE
 */
@Entity
@Table(name = "SERVICE_TYPE")
public class ServiceTypeModel {
	@Id
	@Column(name = "Aurora_ServiceType_Seq", nullable = false)
	private int Aurora_ServiceType_Seq;

	@Column(name = "Service_Type_Value", columnDefinition = "char(30)", nullable = false)
	private String Service_Type_Value;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Aurora_ServiceType_Seq_fk", referencedColumnName = "Aurora_ServiceType_Seq")
	List<SowMasterModel> smodel = new ArrayList<>();

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Aurora_ServiceType_v_Seq_fk", referencedColumnName = "Aurora_ServiceType_Seq")
	List<ProjectMasterModel> pmmodel = new ArrayList<>();

	public ServiceTypeModel() {

	}

	public ServiceTypeModel(int aurora_ServiceType_Seq, String service_Type_Value, List<SowMasterModel> smodel,
			List<ProjectMasterModel> pmmodel) {
		super();
		Aurora_ServiceType_Seq = aurora_ServiceType_Seq;
		Service_Type_Value = service_Type_Value;
		this.smodel = smodel;
		this.pmmodel = pmmodel;
	}

	public int getAurora_ServiceType_Seq() {
		return Aurora_ServiceType_Seq;
	}

	public void setAurora_ServiceType_Seq(int aurora_ServiceType_Seq) {
		Aurora_ServiceType_Seq = aurora_ServiceType_Seq;
	}

	public String getService_Type_Value() {
		return Service_Type_Value;
	}

	public void setService_Type_Value(String service_Type_Value) {
		Service_Type_Value = service_Type_Value;
	}

	public List<SowMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}

	public List<ProjectMasterModel> getPmmodel() {
		return pmmodel;
	}

	public void setPmmodel(List<ProjectMasterModel> pmmodel) {
		this.pmmodel = pmmodel;
	}

}

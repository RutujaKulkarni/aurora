package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.time.LocalDate;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.virtusa.auroraops.annotations.SowField;

/**
 * @author Keerthana
 * @category Master table SOW_MASTER
 */
@Entity
@Table(name = "SOW_MASTER")
public class SowMasterModel {

	@Id // @GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Aurora_SOW_Seq", nullable = false)
	@SowField(col = "SOW_Id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long sowId;

	@Column(name = "SOW_Contract_Id", columnDefinition = "char(15)", nullable = false)
	@SowField(col = "SOW_Contract_Id")
	private String sowContractId;

	@Column(name = "SOW_Contract_Pred_Id", columnDefinition = "char(40)", nullable = false)
	@SowField(col = "SOW_Contract_Pred_Id")
	private String sowContractPredId;

	@Column(name = "Contract_Name", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Contract_Name")
	private String contractName;

	@Column(name = "Signed_Effective_Date", nullable = false)
	@SowField(col = "Signed_Effective_Date")
	private LocalDate signedEffectiveDate;

	@Column(name = "Sow_Start_Date", nullable = false)
	@SowField(col = "Sow_Start_Date")
	private LocalDate sowStartDate;

	@Column(name = "Sow_End_Date", nullable = false)
	@SowField(col = "Sow_End_Date")
	private LocalDate sowEndDate;

	@Column(name = "tenure", nullable = false)
	@SowField(col = "tenure")
	private int tenure;

	@Column(name = "FG_Id", columnDefinition = "char(30)", nullable = true)
	@SowField(col = "FG_Id")
	private String fgId;

	@Column(name = "Source_Data", columnDefinition = "char(45)", nullable = false)
	@SowField(col = "Source_Data")
	private String sourceData;

	@Column(name = "Status", columnDefinition = "char(1)", nullable = false)
	@SowField(col = "SOW_Status")
	private String status;

	//@Column(name = "Citi_Legal_Entity_Seq_fk", nullable = true)
	//private long auroraCitiLegalEntitySeqFk;

	@Column(name = "Geography", columnDefinition = "char(10)", nullable = false)
	@SowField(col = "Geography")
	private String geography;

	//@Column(name = "Service_Type_Seq_fk", nullable = true)
	//private long auroraServiceTypeSeqFk;

	//@Column(name = "Sector_Type_Seq_fk", nullable = true)
	//private long auroraSectorTypeSeqFk;

	@Column(name = "Area", columnDefinition = "char(10)", nullable = false)
	@SowField(col = "Area")
	private String area;

	//@Column(name = "Business_Unit_Seq_fk", nullable = true)
	//private long auroraBusinessUnitSeqFk;

	@Column(name = "Citi_SOW_Owner_Name", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Citi_SOW_Owner_Name")
	private String citiSowOwnerName;

	@Column(name = "Citi_SOW_Owner_Email_Id", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Citi_SOW_Owner_EmailId")
	private String citiSowOwnerEmailId;

	@Column(name = "CITI_PM", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Citi_PM")
	private String citiPM;

	@Column(name = "CITI_PM_EmailId", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Citi_PM_EmailId")
	private String citiPMEmailId;

	@Column(name = "Virtusa_PM_Name", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Virtusa_PM_Name")
	private String virtusaPMName;

	@Column(name = "Virtusa_PM_EmailId", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Virtusa_PM_EmailId")
	private String virtusaPMEmailId;

	@Column(name = "AutoEmail_TriggeredFlag", columnDefinition = "char(1)", nullable = false)
	@SowField(col = "AutoEmail_TriggeredFlag")
	private String autoEmailTriggeredFlag;

	@Column(name = "AutoEmail_TriggeredDate", nullable = false)
	@SowField(col = "AutoEmail_TriggeredDate")
	private LocalDate autoEmailTriggeredDate;

	@Column(name = "Key_Personnel_SOW_Count", nullable = false)
	@SowField(col = "Key_Personnel_SOW_Count")
	private int keyPersonnelSOWCount;

	@Column(name = "COB_Applicability", columnDefinition = "char(1)", nullable = false)
	@SowField(col = "COB_Applicability")
	private String cobApplicability;

	@Column(name = "Remarks", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Remarks")
	private String remarks;

	@Column(name = "Created_Date", nullable = false)
	@SowField(col = "Created_Date")
	private LocalDate createdDate;

	@Column(name = "Created_By", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Created_By")
	private String createdBy;

	@Column(name = "Modified_Date", nullable = false)
	@SowField(col = "Modified_Date")
	private LocalDate modifiedDate;

	@Column(name = "Modified_By", columnDefinition = "char(100)", nullable = false)
	@SowField(col = "Modified_By")
	private String modifiedBy;
	
	@ManyToOne
	@JoinColumn(name = "Aurora_Citi_Legal_Entity_Seq_fk", referencedColumnName = "Aurora_Citi_Legal_Entity_Seq", nullable = false)
	private CitiLegalEntityModel citiLegalEntity;

	@ManyToOne
	@JoinColumn(name = "Aurora_Business_Unit_Seq_fk", referencedColumnName = "Aurora_Business_Unit_Seq", nullable = false)
	private BusinessUnitModel businessUnitModel;

	@ManyToOne
	@JoinColumn(name = "Aurora_ServiceType_Seq_fk", referencedColumnName = "Aurora_ServiceType_Seq", nullable = false)
	private ServiceTypeModel serviceTypeModel;

	@ManyToOne
	@JoinColumn(name = "Aurora_Sector_Seq_fk", referencedColumnName = "Aurora_Sector_Seq", nullable = false)
	private SectorModel sectorModel;

	public Long getSowId() {
		return sowId;
	}

	public void setSowId(Long sowId) {
		this.sowId = sowId;
	}

	public String getSowContractId() {
		return sowContractId;
	}

	public void setSowContractId(String sowContractId) {
		this.sowContractId = sowContractId;
	}

	public String getSowContractPredId() {
		return sowContractPredId;
	}

	public void setSowContractPredId(String sowContractPredId) {
		this.sowContractPredId = sowContractPredId;
	}

	public String getContractName() {
		return contractName;
	}

	public void setContractName(String contractName) {
		this.contractName = contractName;
	}

	public LocalDate getSignedEffectiveDate() {
		return signedEffectiveDate;
	}

	public void setSignedEffectiveDate(LocalDate signedEffectiveDate) {
		this.signedEffectiveDate = signedEffectiveDate;
	}

	public LocalDate getSowStartDate() {
		return sowStartDate;
	}

	public void setSowStartDate(LocalDate sowStartDate) {
		this.sowStartDate = sowStartDate;
	}

	public LocalDate getSowEndDate() {
		return sowEndDate;
	}

	public void setSowEndDate(LocalDate sowEndDate) {
		this.sowEndDate = sowEndDate;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public String getFgId() {
		return fgId;
	}

	public void setFgId(String fgId) {
		this.fgId = fgId;
	}

	public String getSourceData() {
		return sourceData;
	}

	public void setSourceData(String sourceData) {
		this.sourceData = sourceData;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getGeography() {
		return geography;
	}

	public void setGeography(String geography) {
		this.geography = geography;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCitiSowOwnerName() {
		return citiSowOwnerName;
	}

	public void setCitiSowOwnerName(String citiSowOwnerName) {
		this.citiSowOwnerName = citiSowOwnerName;
	}

	public String getCitiSowOwnerEmailId() {
		return citiSowOwnerEmailId;
	}

	public void setCitiSowOwnerEmailId(String citiSowOwnerEmailId) {
		this.citiSowOwnerEmailId = citiSowOwnerEmailId;
	}

	public String getCitiPM() {
		return citiPM;
	}

	public void setCitiPM(String citiPM) {
		this.citiPM = citiPM;
	}

	public String getCitiPMEmailId() {
		return citiPMEmailId;
	}

	public void setCitiPMEmailId(String citiPMEmailId) {
		this.citiPMEmailId = citiPMEmailId;
	}

	public String getVirtusaPMName() {
		return virtusaPMName;
	}

	public void setVirtusaPMName(String virtusaPMName) {
		this.virtusaPMName = virtusaPMName;
	}

	public String getVirtusaPMEmailId() {
		return virtusaPMEmailId;
	}

	public void setVirtusaPMEmailId(String virtusaPMEmailId) {
		this.virtusaPMEmailId = virtusaPMEmailId;
	}

	public String getAutoEmailTriggeredFlag() {
		return autoEmailTriggeredFlag;
	}

	public void setAutoEmailTriggeredFlag(String autoEmailTriggeredFlag) {
		this.autoEmailTriggeredFlag = autoEmailTriggeredFlag;
	}

	public LocalDate getAutoEmailTriggeredDate() {
		return autoEmailTriggeredDate;
	}

	public void setAutoEmailTriggeredDate(LocalDate autoEmailTriggeredDate) {
		this.autoEmailTriggeredDate = autoEmailTriggeredDate;
	}

	public int getKeyPersonnelSOWCount() {
		return keyPersonnelSOWCount;
	}

	public void setKeyPersonnelSOWCount(int keyPersonnelSOWCount) {
		this.keyPersonnelSOWCount = keyPersonnelSOWCount;
	}

	public String getCobApplicability() {
		return cobApplicability;
	}

	public void setCobApplicability(String cobApplicability) {
		this.cobApplicability = cobApplicability;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(LocalDate modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public CitiLegalEntityModel getCitiLegalEntity() {
		return citiLegalEntity;
	}

	public void setCitiLegalEntity(CitiLegalEntityModel citiLegalEntity) {
		this.citiLegalEntity = citiLegalEntity;
	}

	public BusinessUnitModel getBusinessUnitModel() {
		return businessUnitModel;
	}

	public void setBusinessUnitModel(BusinessUnitModel businessUnitModel) {
		this.businessUnitModel = businessUnitModel;
	}

	public ServiceTypeModel getServiceTypeModel() {
		return serviceTypeModel;
	}

	public void setServiceTypeModel(ServiceTypeModel serviceTypeModel) {
		this.serviceTypeModel = serviceTypeModel;
	}

	public SectorModel getSectorModel() {
		return sectorModel;
	}

	public void setSectorModel(SectorModel sectorModel) {
		this.sectorModel = sectorModel;
	}

	@Override
	public String toString() {
		return "SowMasterModel [sowId=" + sowId + ", sowContractId=" + sowContractId + ", sowContractPredId="
				+ sowContractPredId + ", contractName=" + contractName + ", signedEffectiveDate=" + signedEffectiveDate
				+ ", sowStartDate=" + sowStartDate + ", sowEndDate=" + sowEndDate + ", tenure=" + tenure + ", fgId="
				+ fgId + ", sourceData=" + sourceData + ", status=" + status + ", geography=" + geography + ", area="
				+ area + ", citiSowOwnerName=" + citiSowOwnerName + ", citiSowOwnerEmailId=" + citiSowOwnerEmailId
				+ ", citiPM=" + citiPM + ", citiPMEmailId=" + citiPMEmailId + ", virtusaPMName=" + virtusaPMName
				+ ", virtusaPMEmailId=" + virtusaPMEmailId + ", autoEmailTriggeredFlag=" + autoEmailTriggeredFlag
				+ ", autoEmailTriggeredDate=" + autoEmailTriggeredDate + ", keyPersonnelSOWCount="
				+ keyPersonnelSOWCount + ", cobApplicability=" + cobApplicability + ", remarks=" + remarks
				+ ", createdDate=" + createdDate + ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate
				+ ", citiLegalEntity=" + citiLegalEntity + ", businessUnitModel=" + businessUnitModel
				+ ", serviceTypeModel=" + serviceTypeModel + ", sectorModel=" + sectorModel + "]";
	}

	public SowMasterModel(Long sowId, String sowContractId, String sowContractPredId, String contractName,
			LocalDate signedEffectiveDate, LocalDate sowStartDate, LocalDate sowEndDate, int tenure, String fgId,
			String sourceData, String status, String geography, String area, String citiSowOwnerName,
			String citiSowOwnerEmailId, String citiPM, String citiPMEmailId, String virtusaPMName,
			String virtusaPMEmailId, String autoEmailTriggeredFlag, LocalDate autoEmailTriggeredDate,
			int keyPersonnelSOWCount, String cobApplicability, String remarks, LocalDate createdDate, String createdBy,
			LocalDate modifiedDate, CitiLegalEntityModel citiLegalEntity, BusinessUnitModel businessUnitModel,
			ServiceTypeModel serviceTypeModel, SectorModel sectorModel) {
		super();
		this.sowId = sowId;
		this.sowContractId = sowContractId;
		this.sowContractPredId = sowContractPredId;
		this.contractName = contractName;
		this.signedEffectiveDate = signedEffectiveDate;
		this.sowStartDate = sowStartDate;
		this.sowEndDate = sowEndDate;
		this.tenure = tenure;
		this.fgId = fgId;
		this.sourceData = sourceData;
		this.status = status;
		this.geography = geography;
		this.area = area;
		this.citiSowOwnerName = citiSowOwnerName;
		this.citiSowOwnerEmailId = citiSowOwnerEmailId;
		this.citiPM = citiPM;
		this.citiPMEmailId = citiPMEmailId;
		this.virtusaPMName = virtusaPMName;
		this.virtusaPMEmailId = virtusaPMEmailId;
		this.autoEmailTriggeredFlag = autoEmailTriggeredFlag;
		this.autoEmailTriggeredDate = autoEmailTriggeredDate;
		this.keyPersonnelSOWCount = keyPersonnelSOWCount;
		this.cobApplicability = cobApplicability;
		this.remarks = remarks;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
		this.modifiedDate = modifiedDate;
		this.citiLegalEntity = citiLegalEntity;
		this.businessUnitModel = businessUnitModel;
		this.serviceTypeModel = serviceTypeModel;
		this.sectorModel = sectorModel;
	}

	// -------------------------------------------------
	
}

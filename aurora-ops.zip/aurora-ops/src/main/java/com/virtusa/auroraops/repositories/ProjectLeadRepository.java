package com.virtusa.auroraops.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.virtusa.auroraops.dto.DeliveryOperationsDTO;
import com.virtusa.auroraops.models.ProjectLeadId;
import com.virtusa.auroraops.models.ProjectLeadingIndicatorModel;
@Repository
public interface ProjectLeadRepository extends JpaRepository<ProjectLeadingIndicatorModel,ProjectLeadId> {

	@Query(value = "select p.velocity_ProjectCode AS projectCode, "
			+ "c.Chorus_Project_Name AS projectName, "
			+ "l.Project_Health AS projectHealth, "
			+ "l.Onsite_FTE_Tier0 AS onsiteFteCount, "
			+ "l.Offshore_FTE_Tier0 AS offshoreFteCount, "
			+ "l.Past_Due_RRs AS pastDueRrs, "
			+ "l.Ageing_Of_PastDue_RRs AS ageingOfPastDueRrs, "
			+ "l.Resource_Onboarding_Delay AS resourceOnboardingDelay, "
			+ "l.EIQ_Baselining_Of_Resources AS eiqBaseliningOfResources, "
			+ "l.Churn_Attrition_Count AS attritionCount, "
			+ "l.Revenue AS revenue, "
			+ "l.Cost AS cost, "
			+ "l.Margin AS margin, "
			+ "c.Chorus_Code AS chorusCode, "
			+ "l.Year AS year, "
			+ "l.Month AS month "
			+ "FROM project_master p INNER JOIN chorus_master c ON p.Aurora_Project_Seq = c.Aurora_Project_Seq_fk "
			+ "INNER JOIN project_leading_indicator l ON c.Chorus_Code = l.Chorus_Code_fk", nativeQuery = true)
	public List<DeliveryOperationsDTO> getJoinInformation();
	
}

package com.virtusa.auroraops.dto;

import java.math.BigDecimal;


/**
 * This interface acts as a data transfer object
 * 
 * @author kulka
 *
 */
public interface DeliveryOperationsDTO {
	public int getYear();

	public String getMonth();

	public int getChorusCode();

	public String getProjectCode();

	public String getProjectName();

	public String getProjectHealth();

	public int getOnsiteFteCount();

	public int getOffshoreFteCount();

	public int getPastDueRrs();

	public int getAgeingOfPastDueRrs();

	public String getResourceOnboardingDelay();

	public String getEiqBaseliningOfResources();

	public int getAttritionCount();

	public int getRevenue();

	public int getCost();

	public BigDecimal getMargin();
}

package com.virtusa.auroraops.models;
//package com.virtusa.auroraops.models;

//package com.virtusa.auroraops.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author pradip
 * @category Master table 
 * RESOURCE_MASTER
 */
@Entity
@Table(name = "RESOURCE_MASTER")

public class ResourcesMasterModel {

	@Id
	@Column(name = "Employee_Id", nullable = false)
	private int Employee_Id;

	@Column(name = "Employee_Firstname", columnDefinition = "char(30)", nullable = false)
	private String Employee_Firstname;

	@Column(name = "Employee_Lastname", columnDefinition = "char(30)", nullable = false)
	private String Employee_Lastname;

	@Column(name = "Employee_Address", columnDefinition = "char(30)", nullable = false)
	private String Employee_Address;

	@Column(name = "SOE_ID", columnDefinition = "char(30)", nullable = false)
	private String SOE_ID;

	@Column(name = "GE_ID", columnDefinition = "char(30)", nullable = false)
	private String GE_ID;

	@Column(name = "Created_By", columnDefinition = "char(30)", nullable = false)
	private String Created_By;

	@Column(name = "Modified_By", columnDefinition = "char(30)", nullable = false)
	private String Modified_By;

	@Column(name = "Created_Date", nullable = false)
	private Date Created_Date;

	@Column(name = "Modified_Date", nullable = false)
	private Date Modified_Date;

	public ResourcesMasterModel() {

	}

	public ResourcesMasterModel(int employee_Id, String employee_Firstname, String employee_Lastname,
			String employee_Address, String sOE_ID, String gE_ID, String created_By, String modified_By,
			Date created_Date, Date modified_Date) {
		super();
		Employee_Id = employee_Id;
		Employee_Firstname = employee_Firstname;
		Employee_Lastname = employee_Lastname;
		Employee_Address = employee_Address;
		SOE_ID = sOE_ID;
		GE_ID = gE_ID;
		Created_By = created_By;
		Modified_By = modified_By;
		Created_Date = created_Date;
		Modified_Date = modified_Date;
	}

	public int getEmployee_Id() {
		return Employee_Id;
	}

	public void setEmployee_Id(int employee_Id) {
		Employee_Id = employee_Id;
	}

	public String getEmployee_Firstname() {
		return Employee_Firstname;
	}

	public void setEmployee_Firstname(String employee_Firstname) {
		Employee_Firstname = employee_Firstname;
	}

	public String getEmployee_Lastname() {
		return Employee_Lastname;
	}

	public void setEmployee_Lastname(String employee_Lastname) {
		Employee_Lastname = employee_Lastname;
	}

	public String getEmployee_Address() {
		return Employee_Address;
	}

	public void setEmployee_Address(String employee_Address) {
		Employee_Address = employee_Address;
	}

	public String getSOE_ID() {
		return SOE_ID;
	}

	public void setSOE_ID(String sOE_ID) {
		SOE_ID = sOE_ID;
	}

	public String getGE_ID() {
		return GE_ID;
	}

	public void setGE_ID(String gE_ID) {
		GE_ID = gE_ID;
	}

	public String getCreated_By() {
		return Created_By;
	}

	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}

	public String getModified_By() {
		return Modified_By;
	}

	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}

	public Date getCreated_Date() {
		return Created_Date;
	}

	public void setCreated_Date(Date created_Date) {
		Created_Date = created_Date;
	}

	public Date getModified_Date() {
		return Modified_Date;
	}

	public void setModified_Date(Date modified_Date) {
		Modified_Date = modified_Date;
	}

}

package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author pradip
 * @category look up table 
 * SECTOR
 */
@Entity
@Table(name = "SECTOR")

public class SectorModel {
	@Id
	@Column(name = "Aurora_Sector_Seq", nullable = false)
	private int Sector_Id;

	@Column(name = "Sector_Value", columnDefinition = "char(30)", nullable = false)
	private String Sector_Value;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Aurora_Sector_Seq_fk", referencedColumnName = "Aurora_Sector_Seq")
	List<SowMasterModel> smodel = new ArrayList<>();

	public SectorModel() {

	}

	public SectorModel(int sector_Id, String sector_Value, List<SowMasterModel> smodel) {
		super();
		Sector_Id = sector_Id;
		Sector_Value = sector_Value;
		this.smodel = smodel;
	}

	public int getSector_Id() {
		return Sector_Id;
	}

	public void setSector_Id(int sector_Id) {
		Sector_Id = sector_Id;
	}

	public String getSector_Value() {
		return Sector_Value;
	}

	public void setSector_Value(String sector_Value) {
		Sector_Value = sector_Value;
	}

	public List<SowMasterModel> getSmodel() {
		return smodel;
	}

	public void setSmodel(List<SowMasterModel> smodel) {
		this.smodel = smodel;
	}

}

package com.virtusa.auroraops.repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.virtusa.auroraops.models.BusinessUnitModel;
@Repository
public interface BusinessMasterRepository extends JpaRepository<BusinessUnitModel,Integer> {

}

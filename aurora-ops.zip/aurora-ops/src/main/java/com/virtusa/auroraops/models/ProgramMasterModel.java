package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author pradip
 * @category Master table 
 * PROGRAM_MASTER
 */
@Entity
@Table(name = "PROGRAM_MASTER")
public class ProgramMasterModel {

	@Id
	@Column(name = "Aurora_Program_Seq", nullable = false)
	private int Aurora_Program_Seq;

	@Column(name = "Program_Name", columnDefinition = "char(100)", nullable = false)
	private String Program_Name;

	@Column(name = "Program_Manager", columnDefinition = "char(100)", nullable = false)
	private String Program_Manager;

	@Column(name = "Created_Date", nullable = false)
	private Date Created_Date;

	@Column(name = "Created_By", columnDefinition = "char(100)", nullable = false)
	private String Created_By;

	@Column(name = "Modified_Date", nullable = false)
	private Date Modified_Date;

	@Column(name = "Modified_By", columnDefinition = "char(100)", nullable = false)
	private String Modified_By;

	/*@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Aurora_Program_Seq_fk", referencedColumnName = "Aurora_Program_Seq")
	List<ProjectMasterModel> pmodel = new ArrayList<>();*/
	// List<SowMasterModel> smodel = new ArrayList<>();

	public ProgramMasterModel() {

	}

	public ProgramMasterModel(int aurora_Program_Seq, String program_Name, String program_Manager, Date created_Date,
			String created_By, Date modified_Date, String modified_By) {
		super();
		Aurora_Program_Seq = aurora_Program_Seq;
		Program_Name = program_Name;
		Program_Manager = program_Manager;
		Created_Date = created_Date;
		Created_By = created_By;
		Modified_Date = modified_Date;
		Modified_By = modified_By;
	}

	public int getAurora_Program_Seq() {
		return Aurora_Program_Seq;
	}

	public void setAurora_Program_Seq(int aurora_Program_Seq) {
		Aurora_Program_Seq = aurora_Program_Seq;
	}

	public String getProgram_Name() {
		return Program_Name;
	}

	public void setProgram_Name(String program_Name) {
		Program_Name = program_Name;
	}

	public String getProgram_Manager() {
		return Program_Manager;
	}

	public void setProgram_Manager(String program_Manager) {
		Program_Manager = program_Manager;
	}

	public Date getCreated_Date() {
		return Created_Date;
	}

	public void setCreated_Date(Date created_Date) {
		Created_Date = created_Date;
	}

	public String getCreated_By() {
		return Created_By;
	}

	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}

	public Date getModified_Date() {
		return Modified_Date;
	}

	public void setModified_Date(Date modified_Date) {
		Modified_Date = modified_Date;
	}

	public String getModified_By() {
		return Modified_By;
	}

	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}

/*	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}*/

}

package com.virtusa.auroraops.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.auroraops.dto.DeliveryOperationsDTO;
import com.virtusa.auroraops.dto.DeliveryOpsView;
import com.virtusa.auroraops.models.ChorusMasterModel;
import com.virtusa.auroraops.models.ProjectLeadId;
import com.virtusa.auroraops.models.ProjectLeadingIndicatorModel;
import com.virtusa.auroraops.models.ProjectMasterModel;
import com.virtusa.auroraops.repositories.ProjectLeadRepository;
import com.virtusa.auroraops.repositories.ProjectMasterRepository;

@Service
public class DeliveryOpsService {

	@Autowired
	private ProjectMasterRepository projectMasterRepo;

	@Autowired
	private ProjectLeadRepository projectLeadRepository;

	/**
	 * This is version #1 of getOpsData method. This was developed in second sprint
	 * cycle and is being phased out.
	 * 
	 * @return List<DeliveryOpsView>
	 */
	public List<DeliveryOpsView> getOpsDataV1() {
		List<ProjectLeadingIndicatorModel> proLeadList = projectLeadRepository.findAll();
		List<DeliveryOpsView> list = new ArrayList<DeliveryOpsView>();

		for (ProjectLeadingIndicatorModel p : proLeadList) {
			ChorusMasterModel chorusModel = p.getChorusModel();
			ProjectMasterModel projectMasterModel = projectMasterRepo.findByChorusModel(chorusModel);
			ModelMapper modelMapper = new ModelMapper();
			DeliveryOpsView delObj = modelMapper.map(p, DeliveryOpsView.class);
			delObj.setProjectName(projectMasterModel.getProject_Name());
			list.add(delObj);
		}
		return list;
	}

	/**
	 * Active version of the getOpsData method
	 * 
	 * @return List<DeliveryOperationsDTO>
	 */
	@Transactional
	public List<DeliveryOperationsDTO> getOpsDataV2() {
		List<DeliveryOperationsDTO> list = projectLeadRepository.getJoinInformation();
		return list;
	}

	public DeliveryOpsView updateData(DeliveryOpsView model, String projectCode) {
		// update ProjectLeadingIndicatorModel
		// no fields being updated in project master for now. project code can be used in that case.
		ProjectLeadId pId = new ProjectLeadId(model.getChorusCode(), model.getYear(), model.getMonth()); // getting ID object
		Optional<ProjectLeadingIndicatorModel> optionalProjectLeadingModel = projectLeadRepository.findById(pId);
		ProjectLeadingIndicatorModel projectLeadingModel = optionalProjectLeadingModel.get();
		projectLeadingModel.setProject_Health(model.getProjectHealth());
		projectLeadingModel.setPast_Due_RRs(model.getPastDueRrs());
		projectLeadingModel.setAgeing_Of_PastDue_RRs(model.getAgeingOfPastDueRrs());
		projectLeadingModel.setResourceOnboardingDelay(model.getResourceOnboardingDelay());
		projectLeadingModel.setEIQ_Baselining_Of_Resources(model.getEiqBaseliningOfResources());
		projectLeadingModel.setChurn_Attrition_Count(model.getAttritionCount());
		projectLeadingModel.setRevenue(model.getRevenue());
		projectLeadingModel.setCost(model.getCost());
		projectLeadingModel.setMargin(model.getMargin());
		ProjectLeadingIndicatorModel projectLeadingModelUpdated = projectLeadRepository.save(projectLeadingModel); //saving modified data

		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(projectLeadingModelUpdated, DeliveryOpsView.class); //mapping the data from project leading indicator model to view model
	}
}

package com.virtusa.auroraops.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.virtusa.auroraops.dto.DeliveryOpsDTO;
import com.virtusa.auroraops.models.ProjectLeadId;
import com.virtusa.auroraops.models.ProjectLeadingIndicatorModel;
import com.virtusa.auroraops.models.ProjectMasterModel;
import com.virtusa.auroraops.repositories.ProjectLeadRepository;
import com.virtusa.auroraops.repositories.ProjectMasterRepository;
import com.virtusa.auroraops.repositories.SegmentMasterRepository;

@Service
public class DeliveryOpsService {

	@Autowired
	private SegmentMasterRepository segmentRepository;

	public void setSegrepository(SegmentMasterRepository segrepository) {
		this.segmentRepository = segrepository;
	}

	@Autowired
	private ProjectMasterRepository projectMasterRepo;

	@Autowired
	private ProjectLeadRepository projectLeadRepository;

	public List<DeliveryOpsDTO> getOpsData() {
		List<ProjectLeadingIndicatorModel> proLeadList = projectLeadRepository.findAll();
		List<ProjectMasterModel> projectMasterList = projectMasterRepo.findAll();
		List<DeliveryOpsDTO> list = new ArrayList<DeliveryOpsDTO>();
		for (ProjectLeadingIndicatorModel p : proLeadList) {
			ModelMapper modelMapper = new ModelMapper();
			DeliveryOpsDTO delObj = modelMapper.map(p, DeliveryOpsDTO.class);
			delObj.setProjectName(projectMasterList.get(0).getProject_Name()); //TODO: change mapping 
			list.add(delObj);
		}
		return list;
	}

	public DeliveryOpsDTO updateData(DeliveryOpsDTO model) {
		// update ProjectLeadingIndicatorModel
		ProjectLeadId pId = new ProjectLeadId(model.getChorus_Code(), model.getYear(), model.getMonth()); // getting ID
																											// object

		Optional<ProjectLeadingIndicatorModel> optionalProjectLeadingModel = projectLeadRepository.findById(pId);
		ProjectLeadingIndicatorModel projectLeadingModel = optionalProjectLeadingModel.get();
		projectLeadingModel.setProject_Health(model.getProjectHealth());
		projectLeadingModel.setPast_Due_RRs(model.getPastDueRrs());
		projectLeadingModel.setAgeing_Of_PastDue_RRs(model.getAgeingOfPastDueRrs());
		projectLeadingModel.setResource_Onboarding_Delay(model.getResourceOnboardingDelays());
		projectLeadingModel.setEIQ_Baselining_Of_Resources(model.getEiqBaseliningOfResources());
		projectLeadingModel.setChurn_Attrition_Count(model.getAttritionCount());
		projectLeadingModel.setRevenue(model.getRevenue());
		projectLeadingModel.setCost(model.getCost());
		projectLeadingModel.setMargin(model.getMargin());
		ProjectLeadingIndicatorModel projectLeadingModelUpdated = projectLeadRepository.save(projectLeadingModel);
		// TODO: update ProjectMasterModel
		// projectName
		ModelMapper modelMapper = new ModelMapper();
		return modelMapper.map(projectLeadingModelUpdated, DeliveryOpsDTO.class);

	}

}

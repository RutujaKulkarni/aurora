package com.virtusa.auroraops.controllers;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.auroraops.dto.DeliveryOpsDTO;
import com.virtusa.auroraops.services.DeliveryOpsService;

@RestController
@RequestMapping("/api/citi-portal")
public class AuroraOpsController {

	@Autowired
	private DeliveryOpsService deliveryOpsService;

	// service to get all details of the dashboard
	@CrossOrigin("*")
	@GetMapping("/getInfo")
	public List<DeliveryOpsDTO> fetchData() { // getInfo
		return deliveryOpsService.getOpsData();
	}

	// service to update the data
	@CrossOrigin("*")
	@PutMapping("/updateDetails")
	public DeliveryOpsDTO updateSowMasterDetails(@RequestBody DeliveryOpsDTO model) {
		System.out.println("** in update data: " + model.toString());
		return this.deliveryOpsService.updateData(model);
	}

	@CrossOrigin("*")
	@GetMapping("/dev-ops/details")
	public List<DeliveryOpsDTO> getDevOpsDetails() {
		return deliveryOpsService.getOpsData();
	}

	@CrossOrigin("*")
	@PutMapping("/dev-ops/{id}")
	public DeliveryOpsDTO updateSowMasterDetails(@RequestBody DeliveryOpsDTO model, @PathVariable String id) {
		System.out.println("** in update data: " + model.toString());
		return this.deliveryOpsService.updateData(model);
	}
}

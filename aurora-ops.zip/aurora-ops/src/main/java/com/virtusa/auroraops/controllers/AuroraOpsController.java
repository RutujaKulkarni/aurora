package com.virtusa.auroraops.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.auroraops.dto.DeliveryOperationsDTO;
import com.virtusa.auroraops.dto.DeliveryOpsView;
import com.virtusa.auroraops.services.DeliveryOpsService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/citi-portal")
public class AuroraOpsController {

	@Autowired
	private DeliveryOpsService deliveryOpsService;

	@GetMapping("/dev-ops/details")
	public List<DeliveryOperationsDTO> getDevOpsDetails() {
		return deliveryOpsService.getOpsDataV2();
	}

	@PutMapping("/dev-ops/{id}")
	public DeliveryOpsView updateSowMasterDetails(@RequestBody DeliveryOpsView model, @PathVariable String id) {
		return this.deliveryOpsService.updateData(model, id); //id is velocity project code here
	}
}

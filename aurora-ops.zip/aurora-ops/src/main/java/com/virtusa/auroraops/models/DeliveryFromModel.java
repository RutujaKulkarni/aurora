package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author pradip
 * @category look up table 
 * DELIVERY_FROM
 */
@Entity
@Table(name = "DELIVERY_FROM")
public class DeliveryFromModel {
	@Id
	@Column(name = "Aurora_Delivery_From_Seq", nullable = false)
	private int Aurora_Delivery_From_Seq;

	@Column(name = "Delivery_From_Value", columnDefinition = "char(30)", nullable = false)
	private String Delivery_From_Value;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Aurora_Delivery_From_Seq_fk", referencedColumnName = "Aurora_Delivery_From_Seq")
	List<ProjectMasterModel> pmodel = new ArrayList<>();

	public DeliveryFromModel() {

	}

	public DeliveryFromModel(int aurora_Delivery_From_Seq, String delivery_From_Value,
			List<ProjectMasterModel> pmodel) {
		super();
		Aurora_Delivery_From_Seq = aurora_Delivery_From_Seq;
		Delivery_From_Value = delivery_From_Value;
		this.pmodel = pmodel;
	}

	public int getAurora_Delivery_From_Seq() {
		return Aurora_Delivery_From_Seq;
	}

	public void setAurora_Delivery_From_Seq(int aurora_Delivery_From_Seq) {
		Aurora_Delivery_From_Seq = aurora_Delivery_From_Seq;
	}

	public String getDelivery_From_Value() {
		return Delivery_From_Value;
	}

	public void setDelivery_From_Value(String delivery_From_Value) {
		Delivery_From_Value = delivery_From_Value;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}

}

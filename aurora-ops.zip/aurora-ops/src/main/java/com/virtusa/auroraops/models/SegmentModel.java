package com.virtusa.auroraops.models;

import javax.persistence.Column;
import javax.persistence.Id;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author pradip
 * @category look up table
 * SEGMENT
 */
@Entity
@Table(name = "SEGMENT")
public class SegmentModel {
	@Id
	@Column(name = "Aurora_Segment_Seq", nullable = false)
	private int Aurora_Segment_Seq;

	@Column(name = "Segment_Value", columnDefinition = "char(30)", nullable = false)
	private String Segment_Value;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "Aurora_Segment_Seq_fk", referencedColumnName = "Aurora_Segment_Seq")
	List<ProjectMasterModel> pmodel = new ArrayList<>();

	public SegmentModel() {

	}

	public SegmentModel(int aurora_Segment_Seq, String segment_Value, List<ProjectMasterModel> pmodel) {
		super();
		Aurora_Segment_Seq = aurora_Segment_Seq;
		Segment_Value = segment_Value;
		this.pmodel = pmodel;
	}

	public int getAurora_Segment_Seq() {
		return Aurora_Segment_Seq;
	}

	public void setAurora_Segment_Seq(int aurora_Segment_Seq) {
		Aurora_Segment_Seq = aurora_Segment_Seq;
	}

	public String getSegment_Value() {
		return Segment_Value;
	}

	public void setSegment_Value(String segment_Value) {
		Segment_Value = segment_Value;
	}

	public List<ProjectMasterModel> getPmodel() {
		return pmodel;
	}

	public void setPmodel(List<ProjectMasterModel> pmodel) {
		this.pmodel = pmodel;
	}

}

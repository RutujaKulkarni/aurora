package com.virtusa.auroraops;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.virtusa.auroraops.controllers.AuroraOpsController;
import com.virtusa.auroraops.dto.DeliveryOperationsDTO;
import com.virtusa.auroraops.repositories.ProjectLeadRepository;
import com.virtusa.auroraops.repositories.ProjectMasterRepository;
import com.virtusa.auroraops.services.DeliveryOpsService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = AuroraOpsController.class)



public class DeliveryOpsControllerTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private DeliveryOpsService deliveryOpsService;

	@MockBean
	private ProjectMasterRepository projectMasterRepo;

	@MockBean
	private ProjectLeadRepository projectLeadRepository;

	List<DeliveryOperationsDTO> mockDeliveryOpsDtoList = new ArrayList<DeliveryOperationsDTO>();
	String mockJsonDeliveryOpsString = "{\"projectCode\":\"1\",\"projectName\":\"Aurora\",\"projectHealth\":\"100\",\"onsiteFteCount\":0,\"offshoreFteCount\":0,\"pastDueRrs\":2,\"ageingOfPastDueRrs\":11,\"resourceOnboardingDelay\":\"11\",\"eiqBaseliningOfResources\":\"2\",\"attritionCount\":12,\"revenue\":0,\"cost\":0,\"margin\":100.00,\"velocityProjectCode\":\"423556\",\"year\":2020,\"month\":\"9\",\"chorus_Code\":1}";

	// testing get call
	@Test
	public void testGetDeliveryOpsData() throws Exception {
		Mockito.when(deliveryOpsService.getOpsDataV2()).thenReturn(mockDeliveryOpsDtoList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/citi-portal/dev-ops/details")
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	// testing post call
	@Test
	public void testAddDeliveryOpsData() throws Exception {
		RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/api/citi-portal/dev-ops/1")
				.accept(MediaType.APPLICATION_JSON).content(mockJsonDeliveryOpsString)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

}

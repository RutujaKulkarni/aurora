package com.virtusa.auroraops;

import static org.junit.jupiter.api.Assertions.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.virtusa.auroraops.dto.DeliveryOpsView;
import com.virtusa.auroraops.models.ChorusMasterModel;
import com.virtusa.auroraops.models.ProjectLeadingIndicatorModel;
import com.virtusa.auroraops.models.ProjectMasterModel;
import com.virtusa.auroraops.repositories.ProjectLeadRepository;
import com.virtusa.auroraops.repositories.ProjectMasterRepository;
import com.virtusa.auroraops.services.DeliveryOpsService;

import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DeliveryOpsServiceTests {

	@Autowired
	private DeliveryOpsService deliveryOpsService;

	@MockBean
	private ProjectMasterRepository projectMasterRepo;

	@MockBean
	private ProjectLeadRepository projectLeadRepository;

	ChorusMasterModel c1 = new ChorusMasterModel(1, "Aurora", Date.valueOf("2020-08-01"), Date.valueOf("2020-10-31"),
			"process template 1", Date.valueOf("2020-09-30"), "Rutuja", Date.valueOf("2020-09-30"), "Rutuja");

	@Test
	public void getOpsDataTest() {

		when(projectLeadRepository.findAll())
				.thenReturn(Stream
						.of(new ProjectLeadingIndicatorModel(1, 2020, "9", "Good", 100, 100, new BigDecimal(100), 10,
								10, 10, 10, 10, new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
								new BigDecimal(1000), new BigDecimal(1000), 200, 300, 400, 500, 500, 300, 300, 400, 350,
								400, 500, 200, new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
								new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
								new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
								225, 250, 31, 45, new BigDecimal(1000), 20, 50, new BigDecimal(1000),
								new BigDecimal(1000), new BigDecimal(1000), 2, "Delayed", "EIQ_Baselining_Of_Resources",
								20, 10, Date.valueOf("2020-09-30"), "Rutuja", Date.valueOf("2020-09-30"), "Rutuja", c1))
						.collect(Collectors.toList()));

		List<ChorusMasterModel> chorusList = new ArrayList<ChorusMasterModel>() {
			{
				add(c1);
			}
		};

		when(projectMasterRepo.findByChorusModel(ArgumentMatchers.any(ChorusMasterModel.class)))
				.thenReturn(new ProjectMasterModel(1, "VP001", "Aurora", "In Progress", "Resource1",
						Date.valueOf("2020-08-01"), Date.valueOf("2020-10-31"), "John Doe", "John Doe",
						"John@virtusa.com", "John Doe", "John@virtusa.com", "John Doe", "John@virtusa.com", "Cluster 1",
						100, 90, 10, "recovery_Time_Objective", "engagement_Plan_Applicability",
						"engagement_Plan_Exemption_Reason", "sLA_Applicability", "kPI_Applicability", 4,
						"project_Life_Cycle", "project_Applicability_Secure_SDLC",
						"project_Mobile_Development_Component", "release_Notes_Applicability",
						"self_Assessment_Applicability", "governance_Report_Applicability",
						"governance_Report_Frequency", "gDPR", "remarks", "highest_Confidentiality",
						Date.valueOf("2020-09-10"), "John Doe", Date.valueOf("2020-09-10"), "John Doe", chorusList));
		System.out.println(deliveryOpsService.getOpsDataV1().toString());
		assertEquals(1, deliveryOpsService.getOpsDataV1().size());
	}

	@Test
	public void updateOpsDataTest() {
		DeliveryOpsView opsDto = new DeliveryOpsView("1", "Aurora", "Moderate", 100, 100, 20, 10, "100",
				"eiqBaseliningOfResources", 56, 100, 140, new BigDecimal(100), 1, 2020, "Sept", "VP001");
		Optional<ProjectLeadingIndicatorModel> pLeadingModel = Optional.of(new ProjectLeadingIndicatorModel(1, 2020,
				"9", "Good", 90, 100, new BigDecimal(100), 10, 10, 10, 10, 10, new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), 200, 300, 400,
				500, 500, 300, 300, 400, 350, 400, 500, 200, new BigDecimal(1000), new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
				new BigDecimal(1000), 225, 250, 31, 45, new BigDecimal(1000), 20, 50, new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), 2, "Delayed", "EIQ_Baselining_Of_Resources", 20, 10,
				Date.valueOf("2020-09-30"), "Rutuja", Date.valueOf("2020-09-30"), "Rutuja", c1));
		when(projectLeadRepository.findById(ArgumentMatchers.any())).thenReturn(pLeadingModel);
		when(projectLeadRepository.save(pLeadingModel.get())).thenReturn(new ProjectLeadingIndicatorModel(1, 2020, "9",
				"Moderate", 100, 100, new BigDecimal(100), 10, 10, 10, 10, 10, new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), 200, 300, 400,
				500, 500, 300, 300, 400, 350, 400, 500, 200, new BigDecimal(1000), new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000), new BigDecimal(1000),
				new BigDecimal(1000), 225, 250, 31, 45, new BigDecimal(1000), 20, 50, new BigDecimal(1000),
				new BigDecimal(1000), new BigDecimal(1000), 2, "Delayed", "EIQ_Baselining_Of_Resources", 20, 10,
				Date.valueOf("2020-09-30"), "Rutuja", Date.valueOf("2020-09-30"), "Rutuja", c1));
		assertNotNull(deliveryOpsService.updateData(opsDto, "1"));
		assertEquals(opsDto.getProjectHealth(), deliveryOpsService.updateData(opsDto, "1").getProjectHealth());
		assertEquals(opsDto.getRevenue(), deliveryOpsService.updateData(opsDto, "1").getRevenue());
	}
}

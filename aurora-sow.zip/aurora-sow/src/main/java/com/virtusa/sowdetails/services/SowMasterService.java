package com.virtusa.sowdetails.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.sowdetails.exception.SOWException;
import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;

@Service
public class SowMasterService {
	@Autowired
	private SowMasterRepository repository;

	public void setRepository(SowMasterRepository repository) {
		this.repository = repository;
	}

	public SowMasterModel saveDetails(@RequestBody SowMasterModel sowMasterModel) {
		// need to check the model for exceptions
		checkSowForExceptions(sowMasterModel);
		sowMasterModel = repository.save(sowMasterModel);
		return sowMasterModel;
	}

	// get the sowmasterDetails
	public List<SowMasterModel> getAllDetails() {
		return repository.findAll();

	}

	// get the sowmasterDetails based on sowid
	public Optional<SowMasterModel> getDetails(@PathVariable String sowid) {
		return repository.findById(Long.parseLong(sowid));
	}

	// get the sowmasterDetails based on sector
	public List<SowMasterModel> getDetailsBySector(@PathVariable String sector) {
		return repository.findBySector(sector);
	}

	// get the sowmasterDetails based on status
	public List<SowMasterModel> getDetailsByStatus(@PathVariable String status) {
		return repository.findByStatus(status);
	}

	// update single row detail

	public SowMasterModel updateDetails(@RequestBody SowMasterModel sowMasterModel) {
		checkSowForExceptions(sowMasterModel);
		return repository.save(sowMasterModel);
	}

	public void checkSowForExceptions(SowMasterModel model) {
		// null checks
		if(model.getSowContractId() == null || model.getSowContractId().isEmpty()) {
			throw new SOWException("SOW contract ID can not be null.");
		}
		if(model.getSowContractPredId() == null || model.getSowContractPredId().isEmpty()) {
			throw new SOWException("SOW contract pred ID can not be null.for SOW with contract ID: " + model.getSowContractId());
		}
		if(model.getContractName() == null || model.getContractName().isEmpty()) {
			throw new SOWException("SOW contract name can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if(model.getSignedEffectiveDate() == null) {
			throw new SOWException("SOW signed effective date can not be null for SOW with contract ID: " + model.getSignedEffectiveDate());
		}
		if (model.getRemarks() == null || model.getRemarks().isEmpty()) {
			throw new SOWException("Remarks can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getCobApplicability() == null || model.getCobApplicability().isEmpty()) {
			throw new SOWException(
					"COB applicability can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getAutoEmailTriggeredDate() == null) {
			throw new SOWException(
					"Auto email triggered date can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getAutoEmailTriggeredFlag() == null || model.getAutoEmailTriggeredFlag().isEmpty()) {
			throw new SOWException(
					"Auto email triggered flag can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getVirtusaPMEmailId() == null || model.getVirtusaPMEmailId().isEmpty()) {
			throw new SOWException(
					"Virtusa PM email ID can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getVirtusaPMName() == null || model.getVirtusaPMName().isEmpty()) {
			throw new SOWException(
					"Virtusa PM name can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getCitiPMEmailId() == null || model.getCitiPMEmailId().isEmpty()) {
			throw new SOWException(
					"Citi PM email can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getCitiPM() == null || model.getCitiPM().isEmpty()) {
			throw new SOWException("Citi PM can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getCitiSowOwnerEmailId() == null || model.getCitiSowOwnerEmailId().isEmpty()) {
			throw new SOWException(
					"Citi Sow owner email can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getCitiSowOwnerName() == null || model.getCitiSowOwnerName().isEmpty()) {
			throw new SOWException(
					"Citi Sow owner name can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getGeography() == null || model.getGeography().isEmpty()) {
			throw new SOWException("Geography can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getStatus() == null || model.getStatus().isEmpty()) {
			throw new SOWException("Status can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getSourceData() == null || model.getSourceData().isEmpty()) {
			throw new SOWException(
					"Source data field can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getSowStartDate() == null) {
			throw new SOWException(
					"Sow start date can not be null for SOW with contract ID: " + model.getSowContractId());
		}
		if (model.getSowEndDate() == null) {
			throw new SOWException(
					"Sow end date can not be null for SOW with contract ID: " + model.getSowContractId());
		}

		// start date should be less than end date
		if (model.getSowStartDate().isAfter(model.getSowEndDate())) {
			throw new SOWException("Start date can't be less than end date. start date: " + model.getSowStartDate()
					+ " end date: " + model.getSowEndDate());
		}
		// single character flag checks
		if (model.getCobApplicability().length() != 1 || (!model.getCobApplicability().equalsIgnoreCase("Y")
				&& !model.getCobApplicability().equalsIgnoreCase("N"))) {
			throw new SOWException(
					"COB applicability field should be a single character value (Y/N) for SOW with contract ID:"
							+ model.getSowContractId());
		}
		if (model.getAutoEmailTriggeredFlag().length() != 1 || (!model.getAutoEmailTriggeredFlag().equalsIgnoreCase("Y")
				&& !model.getAutoEmailTriggeredFlag().equalsIgnoreCase("N"))) {
			throw new SOWException(
					"Auto email triggered flag field should be a single character value (Y/N) for SOW with contract ID:"
							+ model.getSowContractId());
		}
		if (model.getStatus().length() != 1 || (!model.getStatus().equalsIgnoreCase("I")
				&& !model.getStatus().equalsIgnoreCase("A"))) {
			throw new SOWException(
					"Auto email triggered flag field should be a single character value (A/I) for SOW with contract ID: "
							+ model.getSowContractId());
		}

	}
}

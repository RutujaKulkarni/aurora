package com.virtusa.sowdetails.exception;

public class SOWException extends RuntimeException{

	private static final long serialVersionUID = 3873425876915413253L;

	public SOWException() {
		super();
	}

	public SOWException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SOWException(String message, Throwable cause) {
		super(message, cause);
	}

	public SOWException(String message) {
		super(message);
	}

	public SOWException(Throwable cause) {
		super(cause);
	}

	
	
}

package com.virtusa.sowdetails;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class SowMasterApplicationTest {

	@Test
	public void applicationContextTest() {
		SowMasterApplication.main(new String[] {});
	}
}

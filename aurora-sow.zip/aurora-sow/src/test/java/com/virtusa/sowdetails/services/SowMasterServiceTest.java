 package com.virtusa.sowdetails.services;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;

@RunWith(MockitoJUnitRunner.class)
public class SowMasterServiceTest {

	@Mock
	private SowMasterRepository repository;

	@InjectMocks
	SowMasterService sowMasterService; 
	@Autowired
	SowMasterModel sowMasterModel;
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
		sowMasterModel = new SowMasterModel();
		sowMasterService = new SowMasterService();
		sowMasterService.setRepository(repository);

	} 

	/*@Test
	public void saveDetailsTest() {
		
		sowMasterModel.setArea("area");
		sowMasterService.saveDetails(sowMasterModel);

	}

	@Test
	public void getAllDetailsTest() {
		sowMasterModel = new SowMasterModel();
		sowMasterModel.setArea("area");
		sowMasterService.getAllDetails();

	}
	
	@Test
	public void getDetailsTest() {
		sowMasterModel = new SowMasterModel();
		sowMasterModel.setSowId("ID");
		sowMasterService.getDetails(sowMasterModel.getSowId());

	}
	
	@Test
	public void getDetailsBySectorTest() {
		sowMasterModel = new SowMasterModel();
		sowMasterModel.setContractName("name");
		sowMasterService.getDetailsBySector(sowMasterModel.getSector());

	}
	
	@Test
	public void getDetailsByStatusTest() {
		sowMasterModel = new SowMasterModel();
		sowMasterModel.setContractName("name");
		sowMasterService.getDetailsByStatus(sowMasterModel.getStatus());

	}*/


}
